package com.learnkafkastreams.domain;

public record HostInfoDTO(String host, int port) {
}
